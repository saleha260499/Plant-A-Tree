package com.bolton.User.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.bolton.User.entity.OrderEntity;
import com.bolton.User.service.OrderService;
import com.bolton.User.service.UserService;


@Controller

public class homecontroller {
	
	@Autowired
	com.bolton.User.repository.UserRepository userRepository;
	
	@Autowired
	com.bolton.User.repository.ProductRepository productRepository;

	@Autowired
	com.bolton.User.repository.OrderRepository orderRepository;
	
	@Autowired
	com.bolton.User.service.UserService userService;
	
	@Autowired
	com.bolton.User.service.OrderService orderService;
	
	@Autowired
	com.bolton.User.service.LoginService loginService;
	
	@GetMapping("/homepg")
	public String home( ModelMap model) {
		
		return "homepg";
	}
	@PostMapping("/homepg")
	public String home(@RequestParam String fname, ModelMap model, HttpServletRequest request) {
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		if (messages == null) {
			request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
			model.put("msg", messages);
		}
		else {
			model.put("msg", messages);
		}
		model.addAttribute("sessionMessages", messages);
		System.out.println(fname);
		return "homepg";
	}
	
	@GetMapping("/register")
	public String register() 
	{

		return "register";
	}

	@PostMapping("/register")
	public String register(@RequestParam String fname,String dob,String email, String address, String password,ModelMap model, HttpServletRequest request) 
	{
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		com.bolton.User.entity.UserEntity NewUser = new com.bolton.User.entity.UserEntity(fname, dob, email, address, password);
		System.out.println(NewUser);
		userRepository.save(NewUser);
		if(NewUser!=null) {
			model.put("message", "Registered successfully..");
			request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
				messages=email;
				request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
				model.put("msg", messages);
		}
		return "homepg";
	}
	
	@GetMapping({"/index","/login","/home"})
	public String login() 
	{

		return "index";
	}
	
	@PostMapping({"/index","/login","/home"})
	public String persistMessage(@RequestParam String email1, String password1, ModelMap model, HttpServletRequest request) {
	
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		String name = loginService.validateUser(email1,password1);
		
		if(name==null) {
			model.put("error", "Invalid user");
			return "index";
		}else {
			request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
			messages=email1;
			request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
			model.put("msg", messages);
			
		model.put("username",name);
		System.out.println(messages);
		System.out.println(name);
		}
		return "homepg";
		
	}
	@GetMapping("/logout")
	public String destroySession(HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/aboutus")
	public String about( ModelMap model) {
		
		return "aboutus";
	}
	@PostMapping("/aboutus")
	public String aboutus(@RequestParam String fname, ModelMap model, HttpServletRequest request) {
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		if (messages == null) {
			request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
			model.put("msg", messages);
		}
		else {
			model.put("msg", messages);
		}
		model.addAttribute("sessionMessages", messages);
		System.out.println(fname);
		return "aboutus";
	}
	
	@RequestMapping(value = "/order",method = RequestMethod.GET)
	public String order(@RequestParam int pId, HttpServletRequest request,ModelMap model) {
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		int uId= userService.gettingUserId(messages);
		
		int oId=orderService.checkExistingOrder(uId, pId);
		if(oId==0) {
			OrderEntity orderEntity = new OrderEntity(pId,uId);
			orderRepository.save(orderEntity);
			model.put("msg","order placed successfully..");
		}
		else {
			model.put("msg","order alredy exist!");
		}
		return "order";
	}
	@PostMapping("/order")
	public String orderhome() {
		return "order";
	}
}
