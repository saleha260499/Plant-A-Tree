package com.bolton.User.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {
	
	@Autowired
	com.bolton.User.repository.AdminRepository adminRepository;
	
	@Autowired
	com.bolton.User.service.AdminService adminService;
	
	@GetMapping("/aLogin")
	public String adminLogin() {
		return "aLogin";
	}
	
	@PostMapping("/aLogin")
	public String adminLogin(@RequestParam String a_email, String a_password, ModelMap model) {
		String admin= adminService.validateAdmin(a_email,a_password);
		System.out.println(admin);
		model.put("admin",admin);
		return "aIndex";
		
	}
}
