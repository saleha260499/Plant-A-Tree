package com.bolton.User.repository;

import org.springframework.data.repository.CrudRepository;

public interface CartRepository1 extends CrudRepository<com.bolton.User.entity.CartEntity1, Integer>{
	
} 

