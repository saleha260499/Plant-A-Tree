package com.bolton.User.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bolton.User.entity.ProductEntity;
import com.bolton.User.entity.UserEntity;
import com.bolton.User.repository.ProductRepository;

@Service
public class CartService {
	
	@Autowired
	com.bolton.User.repository.CartRepository cartRepository;
	
	/*
	 * public void addtoCart(int cId,UserEntity id, ProductEntity pId, int qty) {
	 * 
	 * com.bolton.User.entity.CartEntity cartEntity= new
	 * com.bolton.User.entity.CartEntity(); cartEntity.setcId(cId);
	 * cartEntity.setId(id); cartEntity.setPId(pId); cartEntity.setQty(qty);
	 * cartRepository.save(cartEntity);
	 * 
	 * }
	 */	
	
	
}