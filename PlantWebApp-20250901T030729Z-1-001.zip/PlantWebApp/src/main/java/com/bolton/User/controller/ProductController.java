package com.bolton.User.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

	List<com.bolton.User.entity.ProductEntity> myProducts;
	
	@Autowired
	private com.bolton.User.service.ProductService productService;

	@Autowired
	com.bolton.User.repository.ProductRepository productRepository;

	@GetMapping("/aIndex")
	public String aIndex() {
		return "/aIndex";
	}

	@PostMapping("/aIndex")
	public String ahome() {
		return "/aIndex";
	}
	
	@RequestMapping(value = "/addProduct",method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView returnAddProduct() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addProduct");
		return mv;
		
	}
	
	@RequestMapping(value = "/viewProduct",method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView returnListProduct()
	{
	  ModelAndView mv = new ModelAndView();
	  Iterable<com.bolton.User.entity.ProductEntity>products =  productRepository.findAll();
	  //List<Product> products = productRepo.findAll();
	  mv.setViewName("viewProduct");
	  mv.addObject("products", products);
	  return mv;
	  
	}
	
	@GetMapping("/deleteProduct")
	public String deleteProduct(@RequestParam int pId) {
		productService.deleteProduct(pId);
		return "/aIndex";
	}
	
	@PostMapping("/addProduct")
	public String addProduct(@RequestParam("pImage") MultipartFile pImage,
			@RequestParam("pName") String pName, 
			@RequestParam("pPrice") int pPrice, 
			@RequestParam("pQuantity") int pQuantity, ModelMap m) {
		productService.addProduct(pImage, pName, pPrice, pQuantity);
		return "/aIndex";
		
	}
	
	@PostMapping("/viewProduct")
	public String viewProduct(ModelMap m) {
		Iterable<com.bolton.User.entity.ProductEntity>products =  productRepository.findAll();
		m.addAttribute("products", products);
		return "/viewProduct";
	}
	
	@RequestMapping(value = "/shop",method = RequestMethod.GET)
	public String shopProduct(ModelMap m1,ModelMap m2, HttpServletRequest request)
	{
		
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		Iterable<com.bolton.User.entity.ProductEntity>products =  productRepository.findAll();
		m1.addAttribute("products", products);
		request.getSession().setAttribute("MY_SESSION_MESSAGES", messages);
		m2.put("msg", messages);
		
	  return "/shop";
	  
	}
	@PostMapping("/shop")
	public String shop() {
		
		return "/shop";
	}
	
	
}
