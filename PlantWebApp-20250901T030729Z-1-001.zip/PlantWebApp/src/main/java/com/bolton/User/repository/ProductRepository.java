package com.bolton.User.repository;




import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bolton.User.entity.ProductEntity;


@Repository
public interface ProductRepository extends CrudRepository<com.bolton.User.entity.ProductEntity, Integer> {
	
	@Query("select p from ProductEntity p")
	Iterable<com.bolton.User.entity.ProductEntity> findAll(String p);
	
//	@Query("select e from ProductEntity e where e.pId like ?1")
	ProductEntity findById(int pId);
	

}
