package com.bolton.User.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bolton.User.entity.UserEntity;
@Repository
public interface UserRepository extends CrudRepository<UserEntity, Integer> {

//	@Query(value= "SELECT u.id FROM new_schema.user_entity u WHERE u.email = 'email'", nativeQuery=true)
//	 public int findByEmail(String email);
	
	//Optional<UserEntity> findBy1Email(String messages);

	UserEntity findById(int id);

	


}
