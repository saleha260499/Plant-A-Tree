package com.bolton.User.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CartEntity1 {


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cId;
	private int qty;
	private int pId;
	private int Id;
	public CartEntity1() {
		
		// TODO Auto-generated constructor stub
	}
	public CartEntity1(int qty, int pId, int id) {
		
		super();
		this.qty = qty;
		this.pId = pId;
		Id = id;
	}
	public int getcId() {
		return cId;
	}
public void setcId(int cId) {
		this.cId = cId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	@Override
	public String toString() {
		return "CartEntity1 [cId=" + cId + ", qty=" + qty + ", pId=" + pId + ", Id=" + Id + "]";
	}
	
}
