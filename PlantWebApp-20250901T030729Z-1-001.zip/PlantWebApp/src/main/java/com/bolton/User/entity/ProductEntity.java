package com.bolton.User.entity;

import java.util.List;

import javax.persistence.*;
@Entity
@Table
public class ProductEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name = "pId")
	private int pId;
	
	
	@Column(name = "pName")
	private String pName;
	
	@Column(name = "pPrice")
	private int pPrice;
	
	@Column(name = "pQuantity")
	private int pQuantity;
	
	@Lob
	@Column(name = "pImage", columnDefinition = " MEDIUMBLOB") 
	private String pImage;
	
	@OneToMany(mappedBy = "productEntity")
	private List<CartEntity> cartEntity;
	
	public ProductEntity() {
		
		// TODO Auto-generated constructor stub
	}
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpPrice() {
		return pPrice;
	}
	public void setpPrice(int pPrice) {
		this.pPrice = pPrice;
	}
	public int getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(int pQuantity) {
		this.pQuantity = pQuantity;
	}
	
	public String getpImage() {
		return pImage;
	}
	public void setpImage(String pImage) {
		this.pImage = pImage;
	}
	
	public List<CartEntity> getCartEntity() {
		return cartEntity;
	}

	public void setCartEntity(List<CartEntity> cartEntity) {
		this.cartEntity = cartEntity;
	}

	@Override
	public String toString() {
		return "ProductEntity [pId=" + pId + ", pName=" + pName + ", pPrice=" + pPrice + ", pQuantity=" + pQuantity
				+ ", pImage=" + pImage + "]";
	}
	
}
