//package com.bolton.User.controller;
//
//import java.util.ArrayList;
//import java.util.Base64;
//import java.util.List;
//import java.util.Optional;
//
//import javax.servlet.http.HttpServletRequest;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.hateoas.Links;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.bolton.User.entity.ProductEntity;
//import com.bolton.User.entity.UserEntity;
//import com.bolton.User.repository.ProductRepository;
//
//
//
//@Controller
//public class CartController {
//
//	@Autowired
//	com.bolton.User.repository.CartRepository cart;
//	
//
//	@Autowired
//	private com.bolton.User.service.ProductService productService;
//
//	@Autowired
//	com.bolton.User.repository.ProductRepository productRepository;
//
//	@Autowired
//	com.bolton.User.repository.UserRepository userRepository;
//	
//	@Autowired
//	com.bolton.User.service.UserService userService;
//	
//	
//	@RequestMapping(value = "/addtoCart",method = RequestMethod.GET)
//	public String cartAdd(@RequestParam ProductEntity pId, HttpServletRequest request,ModelMap model) {
//		
//		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
//		//UserEntity userEntity=messages;
//	
//		com.bolton.User.entity.CartEntity cartEntity= new com.bolton.User.entity.CartEntity(10);
//		//cartEntity.setProductEntity((ProductEntity) productRepository.findById(pId));
//		
//		//UserEntity uId=userService.findByEmail(messages);
//		
//		cartEntity.setProductEntity (pId);
//		cartEntity.setUserEntity(null);
//		cart.save(cartEntity);
//	
//		System.out.println(cart);
//		if(cart!=null)
//		{
//		model.put("add", "Registered successfully..");}
//
//		return "/addtoCart";
//	}	
//	
//	@PostMapping("/addtoCart")
//	public String Addcart() {
//		return "/addtoCart";
//	}
//	
//	
//	@RequestMapping(value = "/checkout",method = RequestMethod.GET)
//	
//	public String returnListProduct(@RequestParam int pId,ModelMap m, HttpServletRequest request)
//	{
//		List<ProductEntity> elements = new ArrayList<ProductEntity>();
//		elements.add((ProductEntity) productRepository.findById(pId));
//		@SuppressWarnings("unchecked")
//		List<ProductEntity> list = (List<ProductEntity>) request.getSession().getAttribute("Cart_Products");
//		//list=Base64.getEncoder().encodeToString(elements.getByte());
//		
//		request.getSession().setAttribute("Cart_Products",list);
//		
//		m.put("products", elements);
//		//user details
////		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
////		List<UserEntity> users = new ArrayList<UserEntity>();
////		users.add((UserEntity)userRepository.findByEmail(messages)); 
////		m.put("users", users);
//		return "/checkout";
//	}
//	
//	@PostMapping("/checkout")
//	public String viewProduct(ModelMap m) {
//		
//		return "/checkout";
//	}
//}
//	
//
