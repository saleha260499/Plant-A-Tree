package com.bolton.User.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bolton.User.entity.UserEntity;


@Service
public class UserService {

	@Autowired
	com.bolton.User.repository.UserRepository userRepository;
	
	public int gettingUserId(String email) {
		int uId=0;
		for(UserEntity userEntity : userRepository.findAll())
		{
			if(userEntity.getEmail().equals(email))
			{
				uId = userEntity.getId();
			}
		}
		return uId;
	}

	public UserEntity findById(int id) {
		
		return this.userRepository.findById(id);
	}
}
