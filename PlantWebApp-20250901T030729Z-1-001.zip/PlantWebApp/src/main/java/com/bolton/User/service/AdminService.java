package com.bolton.User.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bolton.User.entity.AdminEntity;

@Service
public class AdminService {

	@Autowired
	com.bolton.User.repository.AdminRepository adminRepository;
	
	public String validateAdmin(String a_email, String a_password) 
	{
	
		String admin=null;
		
		for(AdminEntity adminEntity : adminRepository.findAll()) {
			
			if(adminEntity.getA_email().equals(a_email) && adminEntity.getA_password().equals(a_password)) {
				admin=adminEntity.getA_email();
			}
		}
		return admin;
	}
}
