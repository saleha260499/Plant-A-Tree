package com.bolton.User.entity;

import java.util.List;

import javax.persistence.*;

@Entity
public class UserEntity {

	@Id
	@GeneratedValue
	private int id;
	 	
	private String fname;
	private String dob;
	private String email;
	
	private String address;
	private String password;
	
	@OneToMany(mappedBy = "userEntity")
	private List<CartEntity> cartEntity;
	
	public UserEntity() {
		
	}
	
	public UserEntity(String fname, String dob, String email, String address, String password) {
		super();
		this.fname=fname;
		this.dob=dob;
		this.email=email;
		
		this.address=address;
		this.password=password;
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public List<CartEntity> getCartEntity() {
		return cartEntity;
	}

	public void setCartEntity(List<CartEntity> cartEntity) {
		this.cartEntity = cartEntity;
	}

	@Override
	public String toString() {
		return "UserEntity [id= "+id+",fname=" + fname + ", dob=" + dob + ", email=" + email + ", address=" + address + ", password=" + password + "]";
	}
}
