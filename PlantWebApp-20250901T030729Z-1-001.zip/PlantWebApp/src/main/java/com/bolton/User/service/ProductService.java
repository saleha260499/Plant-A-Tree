package com.bolton.User.service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.bolton.User.entity.ProductEntity;

@Service
public class ProductService {
	
	@Autowired
	com.bolton.User.repository.ProductRepository productRepository;
	
	public void addProduct(MultipartFile pImage,String pName, int pPrice, int pQuantity) {
		com.bolton.User.entity.ProductEntity pe= new com.bolton.User.entity.ProductEntity();
		String fileName = StringUtils.cleanPath(pImage.getOriginalFilename());
		if(fileName.contains(".."))
		{
			System.out.println("Not a proper file");
		}
		
		try {
			pe.setpImage(Base64.getEncoder().encodeToString(pImage.getBytes() ));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pe.setpName(pName);
		pe.setpPrice(pPrice);
		pe.setpQuantity(pQuantity);
		productRepository.save(pe);
	}
	
	public Iterable<ProductEntity> findAllProducts() {
		
		return this.productRepository.findAll();
	}
	
	public void deleteProduct(int pId) {
		productRepository.deleteById(pId);
	}
	public ProductEntity findById(int pId){
		
		return this.productRepository.findById(pId);
	}
		
}
