package com.bolton.User.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bolton.User.entity.UserEntity;

@Service
public class LoginService {
	@Autowired
	com.bolton.User.repository.UserRepository userRepository;
	
	public String validateUser(String email, String password)
	{
		String name=null;
		
		for (UserEntity userEntity : userRepository.findAll()) {
			
			if(userEntity.getEmail().equals(email) && userEntity.getPassword().equals(password)) {
				name= userEntity.getFname();
				
			}
		}
		return name;
	}
	
	

}
