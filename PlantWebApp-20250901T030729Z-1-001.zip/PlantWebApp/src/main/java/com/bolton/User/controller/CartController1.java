package com.bolton.User.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bolton.User.entity.CartEntity1;
import com.bolton.User.entity.UserEntity;
import com.bolton.User.repository.UserRepository;
import com.bolton.User.entity.*;

@Controller
public class CartController1 {
	
	@Autowired
	private com.bolton.User.service.ProductService productService;

	@Autowired
	com.bolton.User.repository.ProductRepository productRepository;

	@Autowired
	com.bolton.User.repository.UserRepository userRepository;
	
	@Autowired
	com.bolton.User.service.UserService userService;

	
	@Autowired
	com.bolton.User.repository.CartRepository1 cartRepository1;

	
	
	@RequestMapping(value = "/addtoCart",method = RequestMethod.GET)
	public String CartManager(@RequestParam int pId, ModelMap model ,HttpServletRequest request) {
		
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		int uId= userService.gettingUserId(messages);
		CartEntity1 cartEntity1= new CartEntity1(1,pId,uId);
		cartRepository1.save(cartEntity1);
		System.out.println(cartRepository1);
		
		if(cartRepository1!=null)
		{
		model.put("add", "product added to cart successfully..");
		List<ProductEntity> elements = new ArrayList<ProductEntity>();
		elements.add((ProductEntity) productRepository.findById(pId));
		model.put("products", elements);
		}

		return "/addtoCart";
	}
	
	@PostMapping("/addtoCart")
	public String AddtoCart()
	{
		return "/addtoCart";
	}
	@RequestMapping(value = "/checkout",method = RequestMethod.GET)
	public String returnListProduct(@RequestParam int pId,ModelMap m,HttpServletRequest request)
	{
		String messages = (String) request.getSession().getAttribute("MY_SESSION_MESSAGES");
		int id= userService.gettingUserId(messages);
		
		List<ProductEntity> elements = new ArrayList<ProductEntity>();
		elements.add((ProductEntity) productRepository.findById(pId));
		m.put("products", elements);
		
		List<UserEntity> userdetails = new ArrayList<UserEntity>();
		userdetails.add((UserEntity) userRepository.findById(id));
		m.put("users", userdetails);
		return "/checkout";
	}
	
	@PostMapping("/checkout")
	public String viewProduct(ModelMap m) {
		
		return "/checkout";
	}
}
