package com.bolton.User.entity;

import javax.persistence.*;

@Entity
public class CartEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cId;
	private int qty;
	@ManyToOne
	private com.bolton.User.entity.ProductEntity productEntity;
	@ManyToOne
	private com.bolton.User.entity.UserEntity userEntity;
	
	public CartEntity() {
		// TODO Auto-generated constructor stub
	}

	public CartEntity(int qty) {
		super();
		this.qty = qty;
		/*
		 * this.productEntity = productEntity; this.userEntity = userEntity;
		 */
	}

	public int getcId() {
		return cId;
	}

	public void setcId(int cId) {
		this.cId = cId;
	}

	
	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	
	public com.bolton.User.entity.ProductEntity getProductEntity() {
		return productEntity;
	}

	public void setProductEntity(com.bolton.User.entity.ProductEntity productEntity) {
		this.productEntity = productEntity;
	}
	

	

	public com.bolton.User.entity.UserEntity getUserEntity() {
		return userEntity;
	}

	public void setUserEntity(com.bolton.User.entity.UserEntity userEntity) {
		this.userEntity = userEntity;
	}

	public void setId(int i) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String toString() {
		return "CartEntity [cId=" + cId + ", qty=" + qty + ", productEntity=" + productEntity + ", userEntity="
				+ userEntity + "]";
	}

}
