package com.bolton.User.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bolton.User.entity.OrderEntity;

@Service
public class OrderService {
	
	@Autowired 
	com.bolton.User.repository.OrderRepository orderRepository;
	
	public int checkExistingOrder(int uId, int pId)
	{
		int oId=0;
		
		for (OrderEntity orderEntity : orderRepository.findAll()) {
			if(orderEntity.getcId()==uId && orderEntity.getpId()==pId) {
			oId= orderEntity.getoId();}
		}
		return oId;
	}

}
