package com.bolton.User.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class OrderEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int oId;
	
	private int pId;
	private int cId;
	public OrderEntity() {
		
		// TODO Auto-generated constructor stub
	}
	public OrderEntity(int pId, int cId) {
		super();
		//this.oId = oId;
		this.pId = pId;
		this.cId = cId;
	}
	public int getoId() {
		return oId;
	}
	public void setoId(int oId) {
		this.oId = oId;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	@Override
	public String toString() {
		return "OrderEntity [oId=" + oId + ", pId=" + pId + ", cId=" + cId + "]";
	}
	
	
}
